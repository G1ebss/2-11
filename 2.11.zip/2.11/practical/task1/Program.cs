﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("It's easy to win forgiveness for being wrong;");
            Console.WriteLine("being right is what gets you into real trouble.");
            Console.WriteLine("Bjarne Stroustrup");
        }
    }
}
